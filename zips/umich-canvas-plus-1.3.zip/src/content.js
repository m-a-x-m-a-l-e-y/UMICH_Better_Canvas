// Happening Today UMICH Extension


function add_libraries(){
    let header = document.querySelector('head')
    header.insertAdjacentHTML('beforeend' , `
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet"> 
        `)
}
function fetch_request_happening_events(){
    // This returns a promise for the fetch request, which allows us to wait for this function
    // Message is sent, which background.js checks if string matches
    // Then sends back an object 'response'. 
    // response has 2 elements : boolean 'response.success' and json object 'response.json' [or response.error if something went wrong]

    return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(("maize pages happening data request"), (response) => 
    {
        if(response && response.success){
            console.log("Successfully got event data") // console.log(response.json)
            
            resolve(response.json)
        }
        else{
            console.log("Something went wrong with happening data" + response?.error)
            reject(response?.error)
        }
    })
    })
}

function fetch_request_sports_events(){
    // This returns a promise for the fetch request, which allows us to wait for this function
    // Message is sent, which background.js checks if string matches
    // Then sends back an object 'response'. 
    // response has 2 elements : boolean 'response.success' and json object 'response.json' [or response.error if something went wrong]

    return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(("sports data request"), (response) => 
    {
        if(response && response.success){
            console.log("Successfully got sports data") // console.log(response.json)
            
            resolve(response.json)
        }
        else{
            console.log("Something went wrong with sports data" + response?.error)
            reject(response?.error)
        }
    })
    })

}

function sort_events(rawEventsArray){
    // Sorts by time which is fine to sort by string because month # is the first differentiator
    // NOTE : This sorts by strings but does so correctly because year [represented as numbers] comes before
    // months, which allows us to sort purely by string value |
    rawEventsArray.sort((a, b) => a.time - b.time);
    return rawEventsArray;
}
function parse_happening(json_info){
    // turns json object into a sorted list of events
    const AMOUNT_EVENTS_AVAILABLE = 15;
    let eventArray = [];

    //add events found to array, filtering out ones that have already passed
    const now = new Date();
    for(i = 0; i < AMOUNT_EVENTS_AVAILABLE; i++) {
        const eventDate = new Date(json_info.value[i].startsOn)
        if(eventDate >= now) {
            _event = new Event(
                json_info.value[i].name,
                json_info.value[i].organizationName,
                json_info.value[i].id,
                json_info.value[i].startsOn,
                json_info.value[i].endsOn,
                json_info.value[i].location,
                `https://maizepages.umich.edu/event/${json_info.value[i].id}`
            );

            eventArray.push(_event);
        }
    }

    //sort eventArray by date
    eventArray.sort((a, b) => new Date(a.time) - new Date(b.time));
    return eventArray;
}
function parse_sports(json_info) {
    // turns json array into a sorted list of sport events
 
    let sportsArray = [];
 
    // add events found to array, filtering out ones that have already passed
    const now = new Date();
    for (let i = 0; i < json_info.length; i++) {
        const eventDate = new Date(json_info[i].datetime);
        if (eventDate >= now) {
            const _sport = new Sport(
                json_info[i]["Event Number"],
                json_info[i]["Event Type"],
                json_info[i].title,
                json_info[i].link,
                json_info[i].datetime,
                json_info[i].time_display,
                json_info[i].location
            );
            sportsArray.push(_sport);
        }
    }
 
    // sort sportsArray by date
    sportsArray.sort((a, b) => new Date(a.datetime) - new Date(b.datetime));
    return sportsArray;
}

function format_date(time_in){
    return time_in.slice(0,10)
}

function format_time(time_in){
    //so this actually gives time based on current location so will only work properly in EST places oops
    //uses date of event to find offset, accounts for daylight savings
    const dateOfEvent = new Date(time_in);
    const diff = dateOfEvent.getTimezoneOffset() / 60;

    let prefix = 'am'
    //the hour in UTC time
    let UTC_hour = Number(time_in.slice(11, 13))
    //hour converted to local time
    let convertedHour = UTC_hour - diff;
    
    // if the time is negative, add 24 hours to the time
    // in order to produce the equivalent time 
    // in the previous day (ex: -4:00 = 20:00 = 8:00pm)
        if(convertedHour < 0) {
            convertedHour += 24;
        }
        if(convertedHour >=24) {
            convertedHour -= 24;
        }
        //converts to pm if necessary
        if(convertedHour >= 12) {
            prefix = 'pm';
        }

    //hour is what is displayed on the events thing
    let hour = convertedHour % 12
    if(hour == 0) {
        hour = 12
    }
    
    //minutes is diplated on the page
    let minutes = Number(time_in.slice(14,16))
    // 
    // This logic ensures that there are 2 digits in the minutes place
    if(minutes.toString().length === 1){
        let zero = "0"
        zero += minutes
        minutes = zero
    }
    //compiles time to display
    let time = hour + ":" + minutes + " " + prefix
    return time
}

function add_elems_happening(list_of_events) {

    let container = document.querySelector('#content > div:not(#dashboard)')
    container.style.marginBottom = '40px';

    let targetDiv = document.querySelector('#content > div');
    const eventsHtml = list_of_events.slice(0, 15).map(event => `
        <div class="umich-event-row">
            <div>
                <div class="umich-time">${format_time(event.time)}</div>
                <div class="umich-date">${format_date(event.time)}</div>
            </div>
            
            
            <div class="umich-details">
                <div class="umich-title"><a href = "${event.link}">${event.name || "Unknown Event"}</a></div>
                <div class="umich-loc">${event.location || "Location TBD"} • ${event.orgName}</div>
            </div>

            <div class="umich-gcal-col">
                <a href="${event.gcal}" target="_blank" class="umich-gcal-btn" title="Add to Google Calendar">
                    <span>+</span>
                </a>
            </div>

            
        </div>
    `).join('');

    const widgetHtml = `
        <div id="umich-happening">
            <div class="umich-widget-header">Events Happening Soon : </div>
            <div class="umich-events-list">
                ${eventsHtml}
            </div>
        </div>
    `;

    const style = document.createElement('style');
    style.innerHTML = `
        /* Container styling to sit nicely next to the carousel */
       

        /* The Widget Itself */
        #umich-widget-container {
            width: 400px;
            background-color: #ffffff;
            border: 1px solid #e0e0e0;
            // border: none;
            border-radius: 8px;
            // box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            box-shadow: none;
            font-family: 'Roboto', sans-serif;
            overflow: hidden; /* Keeps border-radius clean */
            flex-shrink: 0;
            margin-left: 5px;
        }

        /* UMich Blue Header */     
        .umich-widget-header {
            background-color: #1e88e5; /* UMich Blue */
            color: rgb(229, 242, 255); /* UMich Maize */
            padding: 12px 16px;
            font-weight: bold;
            font-size: 16px;
            text-align: center;
        }

        /* List container with scrollbar just in case */
        .umich-events-list {
            max-height: 150px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
        }

        .umich-date{
            font-size: 10px;
            color: #233e57;
            width: 70px; /* Fixed width so all titles align */
            flex-shrink: 0;
            margin-right: 12px;
            padding-top: 2px;
        }

        /* Individual Event Row */
        .umich-event-row {
            display: flex;
            padding: 12px 16px;
            border-bottom: 1px solid #f0f0f0;
            transition: background-color 0.2s;
        }

        .umich-event-row:last-child {
            border-bottom: none;
        }

        .umich-event-row:hover {
            background-color: #f9f9f9;
        }

        /* Time Column */
        .umich-time {
            font-size: 12px;
            font-weight: bold;
            color: #00274C;
            width: 70px; /* Fixed width so all titles align */
            flex-shrink: 0;
            margin-right: 12px;
            padding-top: 2px;
        }

        /* Details Column */
        .umich-details {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .umich-title {
            font-size: 14px;
            font-weight: bold;
            color: #333333;
            line-height: 1.2;
        }

        .umich-loc {
            font-size: 11px;
            color: #666666;
            line-height: 1.3;
        }

        .umich-gcal-btn{
            margin:4px;
            text-decoration : none;
        }
    `;
    
    document.head.appendChild(style);
    targetDiv.style.display = 'flex';
    targetDiv.style.flexDirection = 'row';
    targetDiv.style.alignItems = 'flex-start';
    targetDiv.style.backgroundColor = 'white';
    targetDiv.style.padding = '0px';
    targetDiv.style.height = '200px'
    targetDiv.insertAdjacentHTML('beforeend', widgetHtml);
}
function  add_elems_UM_sports(list_of_events) {

    let container = document.querySelector('#content > div:not(#dashboard)')
    container.style.marginBottom = '40px';

    let targetDiv = document.querySelector('#content > div');
    const eventsHtml = list_of_events.slice(0, 15).map(event => `
        <div class="umich-event-row">
            <div>
                <div class="umich-time">${format_time(event.datetime)}</div>
                <div class="umich-date">${format_date(event.datetime)}</div>
            </div>
            
            
            <div class="umich-details">
                <div class="umich-title"><a href = "${event.link}">${event.title || "Unknown Event"}</a></div>
                <div class="umich-loc">${event.location || "Location TBD"} • ${event.eventType}</div>
            </div>

            <div class="umich-gcal-col">
                <a href="https://umich.instructure.com/" target="_blank" class="umich-gcal-btn" title="Add to Google Calendar">
                    <span>+</span>
                </a>
            </div>

            
        </div>
    `).join('');

    const widgetHtml = `
        <div id="umich-sports">
            <div class="umich-widget-header">UMICH Sports : </div>
            <div class="umich-events-list">
                ${eventsHtml}
            </div>
        </div>
    `;

    const style = document.createElement('style');
    style.innerHTML = `
        /* Container styling to sit nicely next to the carousel */
       

        /* The Widget Itself */
        #umich-widget-container {
            width: 400px;
            background-color: #ffffff;
            border: 1px solid #e0e0e0;
            // border: none;
            border-radius: 8px;
            // box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            box-shadow: none;
            font-family: 'Roboto', sans-serif;
            overflow: hidden; /* Keeps border-radius clean */
            flex-shrink: 0;
            margin-left: 5px;
        }

        /* UMich Blue Header */     
        .umich-widget-header {
            background-color: #053865; /* UMich Blue */
            color: rgb(229, 242, 255); /* UMich Maize */
            padding: 12px 16px;
            font-weight: bold;
            font-size: 16px;
            text-align: center;
        }

        /* List container with scrollbar just in case */
        .umich-events-list {
            max-height: 150px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
        }

        .umich-date{
            font-size: 10px;
            color: #233e57;
            width: 70px; /* Fixed width so all titles align */
            flex-shrink: 0;
            margin-right: 12px;
            padding-top: 2px;
        }

        /* Individual Event Row */
        .umich-event-row {
            display: flex;
            padding: 12px 16px;
            border-bottom: 1px solid #f0f0f0;
            transition: background-color 0.2s;
        }

        .umich-event-row:last-child {
            border-bottom: none;
        }

        .umich-event-row:hover {
            background-color: #f9f9f9;
        }

        /* Time Column */
        .umich-time {
            font-size: 12px;
            font-weight: bold;
            color: #00274C;
            width: 70px; /* Fixed width so all titles align */
            flex-shrink: 0;
            margin-right: 12px;
            padding-top: 2px;
        }

        /* Details Column */
        .umich-details {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .umich-title {
            font-size: 14px;
            font-weight: bold;
            color: #333333;
            line-height: 1.2;
        }

        .umich-loc {
            font-size: 11px;
            color: #666666;
            line-height: 1.3;
        }

        .umich-gcal-btn{
            margin:4px;
            text-decoration : none;
        }
    `;
    
    document.head.appendChild(style);
    targetDiv.style.display = 'flex';
    targetDiv.style.flexDirection = 'row';
    targetDiv.style.alignItems = 'flex-start';
    targetDiv.style.backgroundColor = 'white';
    targetDiv.style.padding = '0px';
    targetDiv.style.height = '200px'
    targetDiv.insertAdjacentHTML('beforeend', widgetHtml);
}

// function addElemsDining(){
    
    
// }

function show_elems_happening(){
    let elems = document.querySelector("#umich-happening")

    if (elems) {
            elems.style.display = 'inline';
            events.style.display = 'flex'; 
    }

}

function hide_elems_happening(){
    let elems = document.querySelector("#umich-happening");

    if (elems) {
        elems.style.display = 'none'; // 
    }   

}
function show_sports(){
    let elems = document.querySelector("#umich-sports")

    if (elems) {
            elems.style.display = 'inline';
            events.style.display = 'flex';        
    }
}
function hide_sports(){
    let elems = document.querySelector("#umich-sports");

    if (elems) {
        elems.style.display = 'none'; 
    }
}

function show_ads(){
    let adbox = document.querySelector('#content > div:not(#dashboard) > iframe')

    if (adbox) {
        adbox.style.display = 'block';
    }
}

function hide_ads(){
    let adbox = document.querySelector('#content > div:not(#dashboard) > iframe')

    if (adbox) {
        adbox.style.display = 'none'; // Just hide it
    }

}

async function get_settings(){
    // get_settings() pulls chrome storage saved setetings
    try {
        const result = await chrome.storage.sync.get(["happening_toggle","ads_off_toggle","sports_toggle"]);
        
        return {
            happening_option: result.happening_toggle ?? true,
            no_ads_option: result.ads_off_toggle ?? false,
            sports_option: result.sports_toggle ?? true
            
        };
    } catch (error) {
        console.error("Cloud storage error:", error);
        return { happening_option: true, no_ads_option: true, sports_option:true };
    }
}

async function run(){
    // V 1.2 : Sports Events
    try {
        let today_UTC = new Date();
        let offset = today_UTC.getTimezoneOffset() * 60 * 1000;
        let estDate = new Date(today_UTC.getTime() - offset);
        let today_usable = estDate.toISOString().substring(0,10);
        
        const { happening_option, no_ads_option , sports_option} = await get_settings();
        
        add_libraries()
        const info_json_happening = await fetch_request_happening_events()
        const info_json_sports = await fetch_request_sports_events()
        // Parsing
        let events_list = parse_happening(info_json_happening)
        let sports_list = parse_sports(info_json_sports)

        add_elems_happening(events_list)
        add_elems_UM_sports(sports_list)

        if(no_ads_option){
            hide_ads()
        }
        if(!happening_option){
            hide_elems_happening()
        }
        if(!sports_option){
            hide_sports()
        }
    }
    catch (error){
        console.log("error in something likely " + error)
    }
    //



}


// Runtime listener is listening for changes happening after the extension is loaded
// This message is sent from the toggles in the UMich Canvas + settings menu
chrome.runtime.onMessage.addListener((result)=>{
    

    const {message: message_in, status: status_in} = result
    if (!result || typeof result !== 'object' || !result.message) return;
    try{
        if(message_in === "happening_toggle"){
            if(status_in){
                show_elems_happening()
                // chrome.storage.sync.set({ads_off_toggle: (status_in)})
                chrome.storage.sync.set({happening_toggle: (status_in) })
            }
            else{
                hide_elems_happening()
                chrome.storage.sync.set({happening_toggle: (status_in) })
                
            }
        }
        else if(message_in === "ads_off_toggle"){
            if(status_in){
                hide_ads()
                chrome.storage.sync.set({ads_off_toggle: (status_in)})
            }
            else{
                show_ads()
                chrome.storage.sync.set({ads_off_toggle: (status_in)})
            }
        }
        else if(message_in === "sports_toggle"){
            if(status_in){
                show_sports()
                chrome.storage.sync.set({sports_toggle: (status_in)})
            }
            else{
                hide_sports()
                chrome.storage.sync.set({sports_toggle: (status_in)})
            }
        }

    }
    catch(error){
        console.log("ERROR IN RECEIVING RUNTIME MESSAGE " + error)
    }
})


run()





